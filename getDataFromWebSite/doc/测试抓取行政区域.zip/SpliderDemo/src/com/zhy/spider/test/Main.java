package com.zhy.spider.test;

import java.io.UnsupportedEncodingException;
import java.util.List;

import com.zhy.spider.bean.LinkTypeData;
import com.zhy.spider.core.ExtractService;
import com.zhy.spider.rule.Rule;

public class Main {

	private static String url = "http://www.stats.gov.cn/tjsj/tjbz/tjyqhdmhcxhfdm/2015/";
	public static void main(String[] args) throws Exception {
		Rule rule = new Rule(url,null, null,"provincetr", Rule.CLASS, Rule.POST);
		List<LinkTypeData> extracts = ExtractService.extract(rule);
		printf(extracts);
	}
	public static void printf1(List<LinkTypeData> datas) throws Exception
	{
		// 省级
		for (int f = 0; f< datas.size(); f++)
		{
			if (f == 1) {
				break ;
			}
			LinkTypeData data = datas.get(f);
			System.out.println("-------------------------------------省级-------------------------------------");
			String linkText = data.getLinkText();
			String linkHref = data.getLinkHref();
			System.out.println("名称：" + linkText + ",链接：" + linkHref);
			
			// 市级
			String urla = url + linkHref;
			Rule rule = new Rule(urla,null, null,"citytr", Rule.CLASS, Rule.POST);
			List<LinkTypeData> extracts = ExtractService.extract(rule);
			System.out.println(urla);
			for (int i = 0; i< extracts.size() ; i++){
				if (i%2 != 0) {
					System.out.println("===============================市级=====================================");
					LinkTypeData a = extracts.get(i);
					String linkTexta = a.getLinkText();
					String linkHrefa = a.getLinkHref();
					System.out.println("	编码+名称：" + extracts.get(i-1).getLinkText() + "-" + linkTexta + ",链接：" + linkHrefa);
					
					// 如果是空的话就不遍历下级
					if (linkHrefa == null || "".equals(linkHrefa)) {
						continue ;
					}
					// 县级
					String urlb = url + "/" + linkHrefa;
					Rule ruleb = new Rule(urlb,null, null,"countytr", Rule.CLASS, Rule.POST);
					List<LinkTypeData> extractsb = ExtractService.extract(ruleb);
					System.out.println(urlb);
					for (int j = 0; j< extractsb.size() ; j++){
						if (j%2 != 0) {
							System.out.println("===============================县级=====================================");
							LinkTypeData b = extractsb.get(j);
							String linkTextb = b.getLinkText();
							String linkHrefb = b.getLinkHref();
							System.out.println("	编码+名称：" + extractsb.get(j-1).getLinkText() + "-" + linkTextb + ",链接：" + linkHrefb);
							System.out.println("===============================县级=====================================");
							
							
							if (linkHrefb == null || "".equals(linkHrefb)) {
								System.out.println("跳出循环");
								continue ;
							}
							
							// 街道办
							String urlc = urlb.substring(0, urlb.lastIndexOf('/')) + "/" + linkHrefb;
							Rule rulec = new Rule(urlc,null, null,"towntr", Rule.CLASS, Rule.POST);
							List<LinkTypeData> extractsc = ExtractService.extract(rulec);
							System.out.println(urlc);
							for (int k = 0; k< extractsc.size() ; k++){
								if (k%2 != 0) {
									System.out.println("===============================街道办=====================================");
									LinkTypeData c = extractsc.get(k);
									String linkTextc = c.getLinkText();
									String linkHrefc = c.getLinkHref();
									System.out.println("	编码+名称：" + extractsc.get(k-1).getLinkText() + "-" + linkTextc + ",链接：" + linkHrefc);
									System.out.println("===============================街道办=====================================");
									
									if (linkHrefc == null || "".equals(linkHrefc)) {
										System.out.println("跳出循环");
										continue ;
									}
									// 居委会
									String urld = urlc.substring(0, urlc.lastIndexOf('/')) + "/" + linkHrefc;
									Rule ruled = new Rule(urld,null, null,"villagetr", Rule.CLASS, Rule.POST);
									List<LinkTypeData> extractsd = ExtractService.extract(ruled);
									System.out.println(urld);
									for (int l = 1; l<= extractsd.size() ; l++){
										if (l%3 == 0 && l != 0) {
											System.out.println("===============================居委会=====================================");
											LinkTypeData d = extractsd.get(l-1);
											String linkTextd = d.getLinkText();
											String linkHrefd = d.getLinkHref();
											System.out.println("	编码+名称：" + extractsd.get(l-3).getLinkText() + "-" + linkTextd);
											System.out.println("===============================居委会=====================================");
											
										}
									}
								}
							}
							
							
						}
					}
					
					System.out.println("===============================市级=====================================");
				}
			}
			
			System.out.println("-------------------------------------省级-------------------------------------");
		}
		
	}
	public static void printf(List<LinkTypeData> datas) throws Exception
	{
		// 省级
		for (int f = 0; f< datas.size(); f++)
		{
			if (f == 1) {
				break ;
			}
			LinkTypeData data = datas.get(f);
			System.out.println("-------------------------------------省级-------------------------------------");
			String linkText = data.getLinkText();
			String linkHref = data.getLinkHref();
			System.out.println("名称：" + linkText + ",链接：" + linkHref);
			
			// 市级
			String urla = url + linkHref;
			Rule rule = new Rule(urla,null, null,"citytr", Rule.CLASS, Rule.POST);
			List<LinkTypeData> extracts = ExtractService.extract(rule);
			System.out.println(urla);
			for (int i = 0; i< extracts.size() ; i++){
				if (i%2 != 0) {
					System.out.println("===============================市级=====================================");
					LinkTypeData a = extracts.get(i);
					String linkTexta = a.getLinkText();
					String linkHrefa = a.getLinkHref();
					System.out.println("	编码+名称：" + extracts.get(i-1).getLinkText() + "-" + linkTexta + ",链接：" + linkHrefa);
					
					// 如果是空的话就不遍历下级
					if (linkHrefa == null || "".equals(linkHrefa)) {
						continue ;
					}
					// 县级
					String urlb = url + "/" + linkHrefa;
					Rule ruleb = new Rule(urlb,null, null,"countytr", Rule.CLASS, Rule.POST);
					List<LinkTypeData> extractsb = ExtractService.extract(ruleb);
					System.out.println(urlb);
					for (int j = 0; j< extractsb.size() ; j++){
						if (j%2 != 0) {
							System.out.println("===============================县级=====================================");
							LinkTypeData b = extractsb.get(j);
							String linkTextb = b.getLinkText();
							String linkHrefb = b.getLinkHref();
							System.out.println("	编码+名称：" + extractsb.get(j-1).getLinkText() + "-" + linkTextb + ",链接：" + linkHrefb);
							System.out.println("===============================县级=====================================");
							
							
							if (linkHrefb == null || "".equals(linkHrefb)) {
								System.out.println("跳出循环");
								continue ;
							}
							
							// 街道办
							String urlc = urlb.substring(0, urlb.lastIndexOf('/')) + "/" + linkHrefb;
							Rule rulec = new Rule(urlc,null, null,"towntr", Rule.CLASS, Rule.POST);
							List<LinkTypeData> extractsc = ExtractService.extract(rulec);
							System.out.println(urlc);
							for (int k = 0; k< extractsc.size() ; k++){
								if (k%2 != 0) {
									System.out.println("===============================街道办=====================================");
									LinkTypeData c = extractsc.get(k);
									String linkTextc = c.getLinkText();
									String linkHrefc = c.getLinkHref();
									System.out.println("	编码+名称：" + extractsc.get(k-1).getLinkText() + "-" + linkTextc + ",链接：" + linkHrefc);
									System.out.println("===============================街道办=====================================");
									
									if (linkHrefc == null || "".equals(linkHrefc)) {
										System.out.println("跳出循环");
										continue ;
									}
									// 居委会
									String urld = urlc.substring(0, urlc.lastIndexOf('/')) + "/" + linkHrefc;
									Rule ruled = new Rule(urld,null, null,"villagetr", Rule.CLASS, Rule.POST);
									List<LinkTypeData> extractsd = ExtractService.extract(ruled);
									System.out.println(urld);
									for (int l = 1; l<= extractsd.size() ; l++){
										if (l%3 == 0 && l != 0) {
											System.out.println("===============================居委会=====================================");
											LinkTypeData d = extractsd.get(l-1);
											String linkTextd = d.getLinkText();
											String linkHrefd = d.getLinkHref();
											System.out.println("	编码+名称：" + extractsd.get(l-3).getLinkText() + "-" + linkTextd);
											System.out.println("===============================居委会=====================================");
											
										}
									}
								}
							}
							
							
						}
					}
					
					System.out.println("===============================市级=====================================");
				}
			}
			
			System.out.println("-------------------------------------省级-------------------------------------");
		}

	}

}
